<!-- Contenido 4 columnas -->
<div class="container">
<div class="row">
<div class="col-md-3">
<h3>Dirección</h3>
<img src="img/contacto.png" class="img-responsive">
<p>Columna de ejemplo con texto que tu puedes personalizar.</p>
<a href="" class="btn btn-primary">Mas Informacion</a>
</div>
<div class="col-md-3">
<h3>Cuidados</h3>
<img src="img/cuidado.png" class="img-responsive">
<p>Columna de ejemplo con texto que tu puedes personalizar.</p>
<a href="" class="btn btn-primary">Mas Informacion</a>
</div>
<div class="col-md-3">
<h3>Medicina</h3>
<img src="img/medicina.png" class="img-responsive">
<p>Columna de ejemplo con texto que tu puedes personalizar.</p>
<a href="" class="btn btn-primary">Mas Informacion</a>
</div>
<div class="col-md-3">
<h3>Extras</h3>
<img src="img/comida.png" class="img-responsive">
<p>Columna de ejemplo con texto que tu puedes personalizar.</p>
<a href="" class="btn btn-primary">Mas Informacion</a>
</div>
</div>
</div>